NOBLE SMP BRONZE - RESOURCE PACK v1.8
Minecraft Java 26.2 / resource pack format 88

Merged into the existing Noble SMP Tavern Ballad pack.

Bronze namespace: noble_bronze

Implementation notes:
- Bronze armor uses a custom equipment asset (Roman-style user texture).
- Bronze shield uses the user-built Blockbench geometry and has separate normal/blocking views.
- To obtain real block behavior without a client mod, the plugin uses non-oxidizing vanilla surrogate blocks:
  Waxed Copper Block = Bronze Block
  Waxed Exposed Copper = Raw Bronze Block
  Waxed Copper Door/Trapdoor/Chain/Lantern = Bronze versions
  Waxed Exposed Copper Bars = Bronze Bars
  Damaged Anvil = Bronze Anvil
  Light Weighted Pressure Plate = Bronze Pressure Plate
  These specific surrogate blocks will therefore LOOK bronze whenever this resource pack is enabled. Other copper/iron variants are left alone.
- Armor trim clipping on custom-cut armor geometry is limited by vanilla 26.2 trim rendering. The base Roman armor itself is correct, but some trim patterns may still draw over cut-away shoulder pixels depending on the trim asset.
