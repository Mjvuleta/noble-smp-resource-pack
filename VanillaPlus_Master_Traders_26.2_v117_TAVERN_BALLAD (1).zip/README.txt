MASTER TRADERS v39 - FINAL VILLAGER AUDIT

This build was audited across every villager function. See AUDIT_REPORT_v39.txt.
Key corrections: Alchemist duplicate/old-currency trades removed, no splash/lingering potions, exactly four named Traveler diamond boots, No Fortune lore removed, and blocked Lightbearer progression items enforced.

VanillaPlus Master Traders v32 - Economy & Progression Overhaul

Major changes:
- Botanist: every item costs 2 Gold Nuggets and returns one item, preventing Trader resale duplication.
- Craftsman, Forgemaster, and Guardian: premium Emerald + Diamond pricing and unique item names.
- Added Silk Touch Diamond Axe, named weapon variants, Excalibur, tridents, bows, crossbows, and spear trade attempts.
- Traveler: four protection-specific Diamond Boots of the Traveler; 4 nuggets -> 1 emerald drop exchange retained.
- Alchemist: Gold Ingot potion economy, expanded drinkable potion list, and 4 emeralds -> 1 Gold Ingot drop exchange.
- Curator: cartography supplies, trims, and Netherite upgrade.
- Scholar: simplified readable Master Traders Ledger.
- Lightbearer progression exclusions retained.

Install the ZIP in world/datapacks, remove older Master Traders versions, and run /reload.
Existing named villagers should refresh automatically through v32 tags.

IMPORTANT: ZIP structure and generated commands were checked, but this build has not been launched inside Minecraft. The minecraft:spear trades depend on whether your exact game version provides that item; because every trade is appended separately, unsupported spear lines should not prevent the rest of the merchant from loading.

V33 FIXES
- Restored Alchemist brewing ingredients and stations using Gold Ingots.
- Kept drinkable potion selection and 4 Emeralds -> 1 Gold Ingot exchange.
- Restored Forgemaster 1 Emerald -> 2 Iron Ingots and 64 Diamonds -> 1 Netherite Ingot.
- Raised premium weapon prices; Excalibur is now 64 Emeralds + 32 Diamonds.
- Replaced invalid minecraft:spear outputs with visible named trident-based spear variants.


V34 RESTORATION PATCH
- Restored Scholar book, bookshelf, chiseled bookshelf, paper, glass, lantern, and name-tag trades.
- Restored Traveler turtle helmet, enchanted gold armor, wither skull, piglin head, dragon head, end crystal, compass, spyglass, and bundle trades.
- Preserved v33 Alchemist, Forgemaster, drop exchanges, and four premium diamond Traveler boots.


v35 LEDGER FIX
- Rebuilt written book pages as direct text components instead of escaped JSON strings.
- Existing Scholars refresh to the v35 ledger.


VERSION 36 - FISHERMAN AND GAMBLER
Rename villagers exactly "The Fisherman" or "The Gambler".
The Fisherman has normal fish and ocean trades.
The Gambler has no GUI trades. Drop Gold Blocks, Emerald Blocks, or Diamond Blocks within 2.5 blocks for one randomized payout per block. Higher-value blocks use stronger reward pools, but junk outcomes remain possible.
The Master Traders Ledger has been updated.


V37 FIX: Rebuilt from v31 original merchant recipes, then merged all v36 additions. Original trades are preserved; Botanist remains rebalanced to prevent resale duplication.


V41 FIXES
- Fisherman activation rebuilt using separate trade commands.
- Fisherman version tag bumped so existing named villagers refresh.
- Traveler trades reorganized by currency, essentials, armor, storage, trophies, and ultimate gear.


v42 Fisherman Overhaul:
- Four fish buckets
- Five named axolotl bucket variants
- Prismarine, coral, turtle and ocean treasure trades
- Expanded fisherman buybacks
- River Whisper moved to final trade
- Ledger updated

V102 VILLAGER LEADS
- Crouch + right-click any villager while holding a Lead to leash that villager to yourself.
- Uses the villager's built-in leash data so the normal visible leash and leash physics are used.
- Survival/adventure consumes one Lead; Creative does not.
