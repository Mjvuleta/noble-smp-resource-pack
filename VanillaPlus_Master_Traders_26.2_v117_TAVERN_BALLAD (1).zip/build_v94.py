from pathlib import Path
import re, json, zipfile, shutil
root=Path('/mnt/data/v94_work')
func=root/'data/master_traders/function'
lootroot=root/'data/master_traders/loot_table/gambler_rewards'
lootroot.mkdir(parents=True, exist_ok=True)

# 1) Convert gambler give commands to barrel loot inserts.
pat=re.compile(r'give @p\[distance=\.\.8,limit=1\] (minecraft:[a-z0-9_]+) (\d+)')
created={}
for p in (func/'gambler').rglob('*.mcfunction'):
    txt=p.read_text()
    def repl(m):
        item=m.group(1); count=int(m.group(2))
        key=(item,count)
        stem=f"{item.split(':',1)[1]}_{count}"
        created[key]=stem
        return f"loot insert ^ ^ ^1 loot master_traders:gambler_rewards/{stem}"
    new=pat.sub(repl,txt)
    if new!=txt:
        p.write_text(new)
for (item,count),stem in created.items():
    data={"type":"minecraft:generic","pools":[{"rolls":1,"entries":[{"type":"minecraft:item","name":item,"functions":[{"function":"minecraft:set_count","count":count}]}]}]}
    (lootroot/f'{stem}.json').write_text(json.dumps(data,separators=(',',':')))

# 2) Helpers for barrel validation. Require barrel directly in front and at least 4 empty slots.
barrel_check=func/'gambler/check_barrel.mcfunction'
barrel_check.write_text('''# Executed as and at The Gambler. Barrel must be directly in front.\nscoreboard players set #gambler_barrel_ok mt_temp 0\nexecute if block ^ ^ ^1 minecraft:barrel store result score #gambler_barrel_used mt_temp run data get block ^ ^ ^1 Items\nexecute if block ^ ^ ^1 minecraft:barrel if score #gambler_barrel_used mt_temp matches ..23 run scoreboard players set #gambler_barrel_ok mt_temp 1\n''')

# 3) Rewrite wager processors: only consume when barrel valid; run gamble as gambler so ^ ^ ^1 resolves correctly.
wagers=['coal_block','raw_copper_block','copper_block','raw_iron_block','iron_block','redstone_block','lapis_block','raw_gold_block','gold_block','emerald_block','diamond_block','netherite_block']
for w in wagers:
    p=func/f'gambler/process_{w}.mcfunction'
    p.write_text(f'''# Process one wager only when The Gambler has a usable barrel directly in front.\nscoreboard players set #gambler_barrel_ok mt_temp 0\nexecute at @s as @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1,sort=nearest] at @s run function master_traders:gambler/check_barrel\nexecute if score #gambler_barrel_ok mt_temp matches 1 at @s as @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1,sort=nearest] at @s run function master_traders:gambler/{w}\nexecute if score #gambler_barrel_ok mt_temp matches 1 store result score @s mt_drop_count run data get entity @s Item.count 1\nexecute if score #gambler_barrel_ok mt_temp matches 1 run scoreboard players remove @s mt_drop_count 1\nexecute if score #gambler_barrel_ok mt_temp matches 1 if score @s mt_drop_count matches 0 run kill @s\nexecute if score #gambler_barrel_ok mt_temp matches 1 if score @s mt_drop_count matches 1.. store result entity @s Item.count int 1 run scoreboard players get @s mt_drop_count\nexecute unless score #gambler_barrel_ok mt_temp matches 1 unless entity @s[tag=mt_gambler_barrel_warned] run tellraw @p[distance=..8,limit=1] [{{"text":"[THE GAMBLER] ","color":"gold","bold":true}},{{"text":"Place an empty barrel directly in front of me.","color":"yellow"}}]\nexecute unless score #gambler_barrel_ok mt_temp matches 1 run tag @s add mt_gambler_barrel_warned\n''')

# 4) Restore saplings to Trader GUI and drop-to-sell check.
saplings=['oak_sapling','spruce_sapling','birch_sapling','jungle_sapling','acacia_sapling','dark_oak_sapling','cherry_sapling','pale_oak_sapling']
apply=func/'apply/trader.mcfunction'
txt=apply.read_text()
insert=[]
for s in saplings:
    if f'id:"minecraft:{s}"' not in txt:
        insert.append(f'data modify entity @s Offers.Recipes append value {{buy:{{id:"minecraft:{s}",count:1}},sell:{{id:"minecraft:gold_nugget",count:1}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}}')
# Add near azalea entries rather than alphabetically; trader is a buy list, but group plant items together after setup.
lines=txt.splitlines()
anchor=next((i for i,l in enumerate(lines) if 'minecraft:azalea"' in l), len(lines)-1)
lines[anchor+1:anchor+1]=insert
apply.write_text('\n'.join(lines)+'\n')

check=func/'drop_sell/check.mcfunction'
ct=check.read_text().splitlines()
add=[]
for s in saplings:
    if not any(f'minecraft:{s}' in l for l in ct):
        add.append(f'execute if data entity @s {{Item:{{id:"minecraft:{s}"}}}} run function master_traders:drop_sell/{s}')
# Put saplings beside other plant checks, after initial mob drops before flowers; functionality matters.
ct.extend(add)
check.write_text('\n'.join(ct)+'\n')

# 5) Version notes.
(root/'GAMBLER_V94_BARREL_PAYOUT_AND_TRADER_SAPLINGS.txt').write_text('''V94 changes\n- The Gambler now requires a barrel directly in front of the direction he is facing.\n- Wagers are not consumed if the barrel is missing or nearly full.\n- All normal, jackpot, and progressive rewards are inserted into that barrel.\n- The Trader once again accepts all standard overworld saplings in both GUI trades and throw-to-sell.\n- Saplings pay 1 gold nugget each.\n''')

# update pack description if possible
pm=root/'pack.mcmeta'
try:
    d=json.loads(pm.read_text())
    d['pack']['description']='Master Traders v94 - Gambler Barrel Payout + Trader Saplings'
    pm.write_text(json.dumps(d,indent=2))
except Exception: pass

out=Path('/mnt/data/VanillaPlus_Master_Traders_26.2_v94_GAMBLER_BARREL_AND_SAPLINGS.zip')
if out.exists(): out.unlink()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for p in root.rglob('*'):
        if p.is_file() and p.name!='build_v94.py':
            z.write(p,p.relative_to(root))
print(out)
print('loot tables',len(created))
