execute as @e[type=minecraft:villager,name="The Botanist"] at @s run function master_traders:apply/botanist
tellraw @a [{"text":"[Master Traders v23] ","color":"gold"},{"text":"The Botanist was refreshed.","color":"green"}]
