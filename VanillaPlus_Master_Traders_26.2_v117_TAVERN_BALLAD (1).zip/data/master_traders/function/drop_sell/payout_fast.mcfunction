# Pay large Trader stack sales immediately in legal item stacks.
execute if score @s mt_drop_value matches 64.. run summon minecraft:item ~ ~0.25 ~ {PickupDelay:10s,Item:{id:"minecraft:gold_nugget",count:64}}
execute if score @s mt_drop_value matches 64.. run scoreboard players remove @s mt_drop_value 64
execute if score @s mt_drop_value matches 64.. run function master_traders:drop_sell/payout_fast
execute if score @s mt_drop_value matches 1..63 run summon minecraft:item ~ ~0.25 ~ {Tags:["mt_trader_payout_new"],PickupDelay:10s,Item:{id:"minecraft:gold_nugget",count:1}}
execute if score @s mt_drop_value matches 1..63 store result entity @e[type=minecraft:item,tag=mt_trader_payout_new,distance=..1,sort=nearest,limit=1] Item.count int 1 run scoreboard players get @s mt_drop_value
execute if score @s mt_drop_value matches 1..63 run tag @e[type=minecraft:item,tag=mt_trader_payout_new,distance=..1,sort=nearest,limit=1] remove mt_trader_payout_new
scoreboard players set @s mt_drop_value 0
