# v88: 75% retail buyback. Retail: 32 minecraft:red_sandstone for 1 emerald(s).
# 1 emerald = 4 gold nuggets. Credit scale: 64 points = 1 gold nugget.
# v89 fast-stack processing: consumes the entire dropped stack in one scan.
execute store result score @s mt_drop_count run data get entity @s Item.count 1
scoreboard players set @s mt_drop_rate 6
scoreboard players operation @s mt_drop_value = @s mt_drop_count
scoreboard players operation @s mt_drop_value *= @s mt_drop_rate
scoreboard players operation @e[type=minecraft:villager,name="The Mason",distance=..2.5,limit=1,sort=nearest] mt_mason_credit += @s mt_drop_value
execute as @e[type=minecraft:villager,name="The Mason",distance=..2.5,limit=1,sort=nearest] at @s run function master_traders:drop_sell/mason_payout
kill @s
