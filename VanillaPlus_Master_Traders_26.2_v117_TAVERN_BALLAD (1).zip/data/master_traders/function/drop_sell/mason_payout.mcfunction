# Pays all completed gold nuggets immediately, then keeps fractional credit.
execute if score @s mt_mason_credit matches 64.. run summon minecraft:item ~ ~1 ~ {PickupDelay:10s,Item:{id:"minecraft:gold_nugget",count:1}}
execute if score @s mt_mason_credit matches 64.. run scoreboard players remove @s mt_mason_credit 64
execute if score @s mt_mason_credit matches 64.. run function master_traders:drop_sell/mason_payout
