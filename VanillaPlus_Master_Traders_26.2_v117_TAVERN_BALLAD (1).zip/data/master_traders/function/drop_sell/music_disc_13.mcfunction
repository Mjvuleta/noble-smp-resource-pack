# v99 fast stack processing: consume every complete batch in this dropped stack at once.
execute store result score @s mt_drop_count run data get entity @s Item.count 1
scoreboard players operation @s mt_drop_value = @s mt_drop_count
scoreboard players set #trader_batch mt_drop_rate 1
scoreboard players operation @s mt_drop_value /= #trader_batch mt_drop_rate
scoreboard players set #trader_reward mt_drop_rate 3
scoreboard players operation @s mt_drop_value *= #trader_reward mt_drop_rate
scoreboard players operation @s mt_drop_count %= #trader_batch mt_drop_rate
execute if score @s mt_drop_value matches 1.. run function master_traders:drop_sell/payout_fast
execute if score @s mt_drop_count matches 0 run kill @s
execute if score @s mt_drop_count matches 1.. store result entity @s Item.count int 1 run scoreboard players get @s mt_drop_count
