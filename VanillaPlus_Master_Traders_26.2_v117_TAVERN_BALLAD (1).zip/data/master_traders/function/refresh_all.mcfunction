# Rebuild all named traders directly, regardless of old tags.
execute as @e[type=minecraft:villager,name="The Scholar"] run function master_traders:apply/scholar
execute as @e[type=minecraft:villager,name="The Craftsman"] run function master_traders:apply/craftsman
execute as @e[type=minecraft:villager,name="The Forgemaster"] run function master_traders:apply/forgemaster
execute as @e[type=minecraft:villager,name="The Guardian"] run function master_traders:apply/guardian
execute as @e[type=minecraft:villager,name="The Forester"] run function master_traders:apply/forester
execute as @e[type=minecraft:villager,name="The Alchemist"] run function master_traders:apply/alchemist
execute as @e[type=minecraft:villager,name="The Curator"] run function master_traders:apply/curator
execute as @e[type=minecraft:villager,name="The Traveler"] run function master_traders:apply/traveler
execute as @e[type=minecraft:villager,name="The Mason"] run function master_traders:apply/mason
execute as @e[type=minecraft:villager,name="The Engineer"] run function master_traders:apply/engineer
execute as @e[type=minecraft:villager,name="The Prospector"] run function master_traders:apply/prospector
execute as @e[type=minecraft:villager,name="The Shepherd"] run function master_traders:apply/shepherd
execute as @e[type=minecraft:villager,name="The Cook"] run function master_traders:apply/cook
execute as @e[type=minecraft:villager,name="The Botanist"] run function master_traders:apply/botanist
execute as @e[type=minecraft:villager,name="The Trader"] run function master_traders:apply/trader
execute as @e[type=minecraft:villager,name="The Lightbearer"] run function master_traders:apply/lightbearer
execute as @e[type=minecraft:villager,name="The Light Bearer"] run function master_traders:apply/lightbearer
execute as @e[type=minecraft:villager,name="The Fisherman"] run function master_traders:apply/fisherman
execute as @e[type=minecraft:villager,name="The Gambler"] run function master_traders:apply/gambler
execute as @e[type=minecraft:villager,name="The Stablemaster"] run function master_traders:apply/stablemaster
execute as @e[type=minecraft:villager,name="Mini Mike"] run function master_traders:apply/mini_mike
execute as @e[type=minecraft:villager,name="The Banker"] run function master_traders:apply/banker
execute as @e[type=minecraft:villager,name="The Tavernkeep"] run function master_traders:apply/tavernkeep
execute as @e[type=minecraft:villager,name="The Tavern Keep"] run function master_traders:apply/tavernkeep
execute as @e[type=minecraft:villager,name="Tavernkeep"] run function master_traders:apply/tavernkeep
tellraw @a [{"text":"[Master Traders v82] ","color":"gold"},{"text":"All named villagers were force rebuilt.","color":"green"}]
