tag @e[type=minecraft:villager,name="The Traveler"] remove mt_traveler_v16
tag @e[type=minecraft:villager,name="The Traveler"] remove mt_traveler_v17
tag @e[type=minecraft:villager,name="The Traveler"] remove mt_traveler_v18
tag @e[type=minecraft:villager,name="The Traveler"] remove mt_traveler_v19
tag @e[type=minecraft:villager,name="The Traveler"] remove mt_traveler_v20
tag @e[type=minecraft:villager,name="The Traveler"] remove mt_traveler_v21
execute as @e[type=minecraft:villager,name="The Traveler"] at @s run function master_traders:apply/traveler
