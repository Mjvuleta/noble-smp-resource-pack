# Rebuild nearest Tavernkeep and report whether Offers exists.
execute as @e[type=minecraft:villager,name="The Tavernkeep",sort=nearest,limit=1,distance=..8] at @s run function master_traders:apply/tavernkeep
execute if entity @e[type=minecraft:villager,name="The Tavernkeep",sort=nearest,limit=1,distance=..8,nbt={Offers:{Recipes:[{}]}}] run tellraw @s [{"text":"[Master Traders] ","color":"gold"},{"text":"Tavernkeep has trades loaded.","color":"green"}]
execute unless entity @e[type=minecraft:villager,name="The Tavernkeep",sort=nearest,limit=1,distance=..8,nbt={Offers:{Recipes:[{}]}}] run tellraw @s [{"text":"[Master Traders] ","color":"gold"},{"text":"Tavernkeep still has no trades. Check console datapack function errors.","color":"red"}]
