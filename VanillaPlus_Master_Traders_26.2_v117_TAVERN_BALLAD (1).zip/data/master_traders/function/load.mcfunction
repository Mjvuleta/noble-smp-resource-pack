scoreboard objectives add mt_potion_used minecraft.used:minecraft.potion
scoreboard players add @a mt_potion_used 0
scoreboard objectives add mt_horn_used minecraft.used:minecraft.goat_horn
scoreboard objectives add mt_map_used minecraft.used:minecraft.map
scoreboard players add @a mt_map_used 0
scoreboard players add @a mt_horn_used 0
scoreboard objectives add mt_owner dummy
scoreboard players add #next_owner mt_temp 0
scoreboard objectives add mt_temp dummy
scoreboard objectives add mt_lead_ray dummy
scoreboard objectives add mt_drop_count dummy
scoreboard objectives add mt_drop_value dummy
scoreboard objectives add mt_drop_rate dummy
scoreboard objectives add mt_mason_credit dummy
scoreboard objectives add mt_gambles dummy {"text":"Blocks Gambled","color":"gold"}
scoreboard objectives add mt_jackpots dummy {"text":"Jackpots Won","color":"yellow"}
scoreboard players add #gambler_pool mt_temp 0
scoreboard players add #gambler_tier mt_temp 0
scoreboard players add #gambler_day_timer mt_temp 0
scoreboard players add #gambler_total mt_temp 0
tellraw @a [{"text":"[Master Traders v65] ","color":"gold"},{"text":"Loaded: Map Mount Deeds are one-time use; the Stablemaster Bell remains a reusable horn.","color":"green"}]
execute as @e[type=minecraft:villager,name="The Traveler"] at @s run function master_traders:apply/traveler
execute as @e[type=minecraft:villager,name="The Curator"] at @s run function master_traders:apply/curator
execute as @e[type=minecraft:villager,name="The Prospector"] at @s run function master_traders:apply/prospector
execute as @e[type=minecraft:villager,name="The Botanist"] at @s run function master_traders:apply/botanist
execute as @e[type=minecraft:villager,name="The Forester"] at @s run function master_traders:apply/forester
execute as @e[type=minecraft:villager,name="The Trader"] at @s run function master_traders:apply/trader
execute as @e[type=minecraft:villager,name="The Lightbearer"] at @s run function master_traders:apply/lightbearer
execute as @e[type=minecraft:villager,name="The Light Bearer"] at @s run function master_traders:apply/lightbearer

execute as @e[type=minecraft:villager,name="The Fisherman"] at @s run function master_traders:apply/fisherman
execute as @e[type=minecraft:villager,name="The Gambler"] at @s run function master_traders:apply/gambler
execute as @e[type=minecraft:villager,name="The Taskmaster"] at @s run function master_traders:apply/taskmaster

execute as @e[type=minecraft:villager,name="The Stablemaster"] at @s run function master_traders:apply/stablemaster

scoreboard objectives add mt_mount_preset dummy

tellraw @a [{"text":"[Master Traders v78] ","color":"gold"},{"text":"Forgemaster sells chains, iron bars, and all waxed copper grates.","color":"green"}]

execute as @e[type=minecraft:villager,name="Mini Mike"] at @s run function master_traders:apply/mini_mike
tellraw @a [{"text":"[Master Traders v82] ","color":"gold"},{"text":"Mini Mike loaded with 204 Mini Block trades.","color":"green"}]

# Noble SMP optimization: scheduled every 10 ticks.

# Noble SMP performance edition: split workloads so expensive global scans do not run together.
execute as @e[type=minecraft:villager,name="The Tavernkeep"] at @s run function master_traders:apply/tavernkeep
execute as @e[type=minecraft:villager,name="The Tavern Keep"] at @s run function master_traders:apply/tavernkeep
execute as @e[type=minecraft:villager,name="Tavernkeep"] at @s run function master_traders:apply/tavernkeep
schedule function master_traders:villager_scan 40t replace
schedule function master_traders:item_scan 2t replace
schedule function master_traders:player_tick 2t replace
schedule function master_traders:clock_tick 20t replace

# v92: capture Gambler wager items every tick before the villager can collect them.
schedule function master_traders:gambler_scan 1t replace
