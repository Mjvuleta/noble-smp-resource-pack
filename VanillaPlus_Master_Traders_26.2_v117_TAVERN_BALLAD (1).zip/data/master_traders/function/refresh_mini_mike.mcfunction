execute as @e[type=minecraft:villager,name="Mini Mike"] at @s run function master_traders:apply/mini_mike
tellraw @a [{"text":"[Master Traders v82] ","color":"gold"},{"text":"Mini Mike was refreshed.","color":"green"}]
