# Keep every custom Master Traders villager at its assigned post while preserving normal AI,
# head movement, trading, sounds, and restocking.
execute as @e[type=minecraft:villager,tag=mt_active] run attribute @s minecraft:movement_speed base set 0.0

# Protect all named Master Traders from mobs and other normal damage.
# Commands can still remove them by first clearing Invulnerable or using /kill as an operator.
execute as @e[type=minecraft:villager,tag=mt_active] run data merge entity @s {Invulnerable:1b}

# Explicit protection for The Banker and The Taskmaster.
# Keep normal villager AI enabled: they may look around, make sounds, and trade normally.
# Movement speed 0 prevents wandering; Invulnerable prevents normal damage/death.
execute as @e[type=minecraft:villager,name="The Banker"] run attribute @s minecraft:movement_speed base set 0.0
execute as @e[type=minecraft:villager,name="The Banker"] run data merge entity @s {Invulnerable:1b}
execute as @e[type=minecraft:villager,name="The Taskmaster"] run attribute @s minecraft:movement_speed base set 0.0
execute as @e[type=minecraft:villager,name="The Taskmaster"] run data merge entity @s {Invulnerable:1b}

# Keep purchased mount nameplates from rendering through walls.
execute as @e[tag=mt_purchased_mount] run data merge entity @s {CustomNameVisible:0b}
# Keep Taskmaster nameplate hidden unless vanilla targeting/UI exposes it.
execute as @e[type=minecraft:villager,name="The Taskmaster"] run data merge entity @s {CustomNameVisible:0b}

# Tavernkeep: same protected, stationary AI behavior as the other named traders.
execute as @e[type=minecraft:villager,name="The Tavernkeep"] run data merge entity @s {CustomNameVisible:0b,Invulnerable:1b}

# Tavernkeep aliases: protected, hidden nameplate, normal AI, zero walking speed.
execute as @e[type=minecraft:villager,name="The Tavernkeep"] run attribute @s minecraft:movement_speed base set 0.0
execute as @e[type=minecraft:villager,name="The Tavernkeep"] run data merge entity @s {Invulnerable:1b,CustomNameVisible:0b}
execute as @e[type=minecraft:villager,name="The Tavern Keep"] run attribute @s minecraft:movement_speed base set 0.0
execute as @e[type=minecraft:villager,name="The Tavern Keep"] run data merge entity @s {Invulnerable:1b,CustomNameVisible:0b}
execute as @e[type=minecraft:villager,name="Tavernkeep"] run attribute @s minecraft:movement_speed base set 0.0
execute as @e[type=minecraft:villager,name="Tavernkeep"] run data merge entity @s {Invulnerable:1b,CustomNameVisible:0b}
