# Scan named villagers every two seconds. New or updated traders may take up to 2 seconds to activate.
function master_traders:stationary_named_villagers
execute as @e[type=minecraft:villager,name="Mini Mike",tag=!mt_mini_mike_v85] at @s run function master_traders:apply/mini_mike
execute as @e[type=minecraft:villager,name="The Stablemaster",tag=!mt_stablemaster_v85] at @s run function master_traders:apply/stablemaster
execute as @e[type=minecraft:villager,name="The Scholar",tag=!mt_scholar_v85] at @s run function master_traders:apply/scholar
execute as @e[type=minecraft:villager,name="The Craftsman",tag=!mt_craftsman_v85] at @s run function master_traders:apply/craftsman
execute as @e[type=minecraft:villager,name="The Forgemaster",tag=!mt_forgemaster_v85] at @s run function master_traders:apply/forgemaster
execute as @e[type=minecraft:villager,name="The Guardian",tag=!mt_guardian_v85] at @s run function master_traders:apply/guardian
execute as @e[type=minecraft:villager,name="The Traveler",tag=!mt_traveler_v85] at @s run function master_traders:apply/traveler
execute as @e[type=minecraft:villager,name="The Curator",tag=!mt_curator_v85] at @s run function master_traders:apply/curator
execute as @e[type=minecraft:villager,name="The Alchemist",tag=!mt_alchemist_v85] at @s run function master_traders:apply/alchemist
execute as @e[type=minecraft:villager,name="The Botanist",tag=!mt_botanist_v85] at @s run function master_traders:apply/botanist
execute as @e[type=minecraft:villager,name="The Mason",tag=!mt_mason_v88] at @s run function master_traders:apply/mason
execute as @e[type=minecraft:villager,name="The Forester",tag=!mt_forester_v85] at @s run function master_traders:apply/forester
execute as @e[type=minecraft:villager,name="The Trader",tag=!mt_trader_v85] at @s run function master_traders:apply/trader
execute as @e[type=minecraft:villager,name="The Lightbearer",tag=!mt_lightbearer_v85] at @s run function master_traders:apply/lightbearer
execute as @e[type=minecraft:villager,name="The Light Bearer",tag=!mt_lightbearer_v85] at @s run function master_traders:apply/lightbearer
execute as @e[type=minecraft:villager,name="The Shepherd",tag=!mt_shepherd_v85] at @s run function master_traders:apply/shepherd
execute as @e[type=minecraft:villager,name="The Fisherman",tag=!mt_fisherman_v85] at @s run function master_traders:apply/fisherman
execute as @e[type=minecraft:villager,name="The Gambler",tag=!mt_gambler_v92] at @s run function master_traders:apply/gambler
execute as @e[type=minecraft:villager,name="The Taskmaster",tag=!mt_taskmaster_v106] at @s run function master_traders:apply/taskmaster
execute as @e[type=minecraft:villager,name="The Banker",tag=!mt_banker_v108] at @s run function master_traders:apply/banker
execute as @e[type=minecraft:villager,name="The Tavernkeep",tag=!mt_tavernkeep_v116] at @s run function master_traders:apply/tavernkeep
execute as @e[type=minecraft:villager,name="The Tavern Keep",tag=!mt_tavernkeep_v116] at @s run function master_traders:apply/tavernkeep
execute as @e[type=minecraft:villager,name="Tavernkeep",tag=!mt_tavernkeep_v116] at @s run function master_traders:apply/tavernkeep
schedule function master_traders:villager_scan 40t replace
