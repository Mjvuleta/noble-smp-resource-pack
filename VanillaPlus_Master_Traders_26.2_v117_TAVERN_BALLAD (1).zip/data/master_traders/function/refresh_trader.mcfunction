execute as @e[type=minecraft:villager,name="The Trader"] at @s run function master_traders:apply/trader
tellraw @a [{"text":"[Master Traders v43] ","color":"gold"},{"text":"The Trader was refreshed.","color":"green"}]
