# Legacy scan entry point.
function master_traders:villager_scan
