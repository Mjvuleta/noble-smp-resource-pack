# Tavernkeep Bottomless Mug processing.
scoreboard players add @a mt_potion_used 0
execute as @a[scores={mt_potion_used=1..},tag=mt_mug_5] at @s run function master_traders:tavern/mug_use_5
execute as @a[scores={mt_potion_used=1..},tag=mt_mug_4] at @s run function master_traders:tavern/mug_use_4
execute as @a[scores={mt_potion_used=1..},tag=mt_mug_3] at @s run function master_traders:tavern/mug_use_3
execute as @a[scores={mt_potion_used=1..},tag=mt_mug_2] at @s run function master_traders:tavern/mug_use_2
execute as @a[scores={mt_potion_used=1..},tag=mt_mug_1] at @s run function master_traders:tavern/mug_use_1
scoreboard players set @a[scores={mt_potion_used=1..}] mt_potion_used 0
tag @a remove mt_mug_5
tag @a remove mt_mug_4
tag @a remove mt_mug_3
tag @a remove mt_mug_2
tag @a remove mt_mug_1
execute as @a if items entity @s weapon.mainhand minecraft:potion[minecraft:custom_data~{tavern_item:"bottomless_mug",charges:5}] run tag @s add mt_mug_5
execute as @a if items entity @s weapon.offhand minecraft:potion[minecraft:custom_data~{tavern_item:"bottomless_mug",charges:5}] run tag @s add mt_mug_5
execute as @a if items entity @s weapon.mainhand minecraft:potion[minecraft:custom_data~{tavern_item:"bottomless_mug",charges:4}] run tag @s add mt_mug_4
execute as @a if items entity @s weapon.offhand minecraft:potion[minecraft:custom_data~{tavern_item:"bottomless_mug",charges:4}] run tag @s add mt_mug_4
execute as @a if items entity @s weapon.mainhand minecraft:potion[minecraft:custom_data~{tavern_item:"bottomless_mug",charges:3}] run tag @s add mt_mug_3
execute as @a if items entity @s weapon.offhand minecraft:potion[minecraft:custom_data~{tavern_item:"bottomless_mug",charges:3}] run tag @s add mt_mug_3
execute as @a if items entity @s weapon.mainhand minecraft:potion[minecraft:custom_data~{tavern_item:"bottomless_mug",charges:2}] run tag @s add mt_mug_2
execute as @a if items entity @s weapon.offhand minecraft:potion[minecraft:custom_data~{tavern_item:"bottomless_mug",charges:2}] run tag @s add mt_mug_2
execute as @a if items entity @s weapon.mainhand minecraft:potion[minecraft:custom_data~{tavern_item:"bottomless_mug",charges:1}] run tag @s add mt_mug_1
execute as @a if items entity @s weapon.offhand minecraft:potion[minecraft:custom_data~{tavern_item:"bottomless_mug",charges:1}] run tag @s add mt_mug_1

# Player use-stat checks run ten times per second.
scoreboard players add @a mt_map_used 0
scoreboard players add @a mt_horn_used 0
execute as @a[scores={mt_map_used=0}] if items entity @s weapon.mainhand minecraft:map[minecraft:custom_data~{stable_item:"deed"}] run function master_traders:mount/prepare_map_deed
execute as @a[scores={mt_map_used=1..}] at @s run function master_traders:mount/use_map_deed
execute as @a[scores={mt_horn_used=1..}] at @s run function master_traders:mount/use_item
schedule function master_traders:player_tick 2t replace
