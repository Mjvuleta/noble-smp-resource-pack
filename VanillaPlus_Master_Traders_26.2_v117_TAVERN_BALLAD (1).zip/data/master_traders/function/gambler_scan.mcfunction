# Fast one-tick capture for Gambler wagers. Prevents the villager from collecting wager blocks.
execute as @e[type=minecraft:villager,name="The Gambler"] run data merge entity @s {CanPickUpLoot:0b}
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:coal_block"}}] at @s if entity @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1] run function master_traders:gambler/process_coal_block
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:raw_copper_block"}}] at @s if entity @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1] run function master_traders:gambler/process_raw_copper_block
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:copper_block"}}] at @s if entity @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1] run function master_traders:gambler/process_copper_block
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:raw_iron_block"}}] at @s if entity @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1] run function master_traders:gambler/process_raw_iron_block
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:iron_block"}}] at @s if entity @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1] run function master_traders:gambler/process_iron_block
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:redstone_block"}}] at @s if entity @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1] run function master_traders:gambler/process_redstone_block
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:lapis_block"}}] at @s if entity @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1] run function master_traders:gambler/process_lapis_block
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:raw_gold_block"}}] at @s if entity @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1] run function master_traders:gambler/process_raw_gold_block
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:gold_block"}}] at @s if entity @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1] run function master_traders:gambler/process_gold_block
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:emerald_block"}}] at @s if entity @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1] run function master_traders:gambler/process_emerald_block
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:diamond_block"}}] at @s if entity @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1] run function master_traders:gambler/process_diamond_block
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:netherite_block"}}] at @s if entity @e[type=minecraft:villager,name="The Gambler",distance=..3.5,limit=1] run function master_traders:gambler/process_netherite_block
schedule function master_traders:gambler_scan 1t replace
