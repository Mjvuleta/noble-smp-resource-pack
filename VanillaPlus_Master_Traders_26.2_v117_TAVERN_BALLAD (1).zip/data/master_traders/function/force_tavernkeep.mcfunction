# Manually force-convert the nearest villager within 5 blocks into The Tavernkeep.
data merge entity @e[type=minecraft:villager,sort=nearest,limit=1,distance=..5] {CustomName:'{"text":"The Tavernkeep"}'}
execute as @e[type=minecraft:villager,sort=nearest,limit=1,distance=..5] at @s run function master_traders:apply/tavernkeep
tellraw @s [{"text":"[Master Traders] ","color":"gold"},{"text":"Forced nearest villager to The Tavernkeep.","color":"green"}]
