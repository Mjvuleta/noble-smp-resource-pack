tag @s remove mt_scholar
tag @s remove mt_craftsman
tag @s remove mt_forgemaster
tag @s remove mt_guardian
tag @s remove mt_forester
tag @s remove mt_alchemist
tag @s remove mt_curator
tag @s remove mt_traveler
tag @s remove mt_traveler_v16
tag @s remove mt_traveler_v17
tag @s remove mt_traveler_v18
tag @s remove mt_mason
tag @s remove mt_engineer
tag @s remove mt_prospector
tag @s remove mt_shepherd
tag @s remove mt_cook
tag @s remove mt_v4
tag @s remove mt_v5
tag @s remove mt_v6
tag @s remove mt_v7
tag @s remove mt_v8
tag @s remove mt_v9
tag @s remove mt_v10
tag @s remove mt_v12
tag @s remove mt_v13
tag @s remove mt_v14
data merge entity @s {VillagerData:{profession:"minecraft:shepherd",level:5,type:"minecraft:snow"},PersistenceRequired:1b,Invulnerable:0b}
data remove entity @s Offers
data modify entity @s Offers set value {Recipes:[]}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:black_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:blue_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:brown_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cyan_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:gray_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:green_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:light_blue_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:light_gray_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:lime_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:magenta_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:orange_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:pink_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:purple_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:red_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:white_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:yellow_dye",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:black_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:blue_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:brown_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:cyan_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:gray_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:green_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:light_blue_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:light_gray_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:lime_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:magenta_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:orange_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:pink_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:purple_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:red_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:white_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:yellow_wool",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:black_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:blue_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:brown_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:cyan_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:gray_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:green_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:light_blue_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:light_gray_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:lime_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:magenta_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:orange_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:pink_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:purple_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:red_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:white_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:yellow_carpet",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:black_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:blue_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:brown_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:cyan_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:gray_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:green_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:light_blue_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:light_gray_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:lime_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:magenta_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:orange_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:pink_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:purple_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:red_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:white_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:yellow_bed",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:black_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:blue_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:brown_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:cyan_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:gray_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:green_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:light_blue_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:light_gray_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:lime_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:magenta_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:orange_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:pink_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:purple_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:red_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:white_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:yellow_banner",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:loom",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:shears",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:string",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
# Glow ink sale - convenience price
data modify entity @s Offers.Recipes prepend value {buy:{id:"minecraft:gold_nugget",count:5},sell:{id:"minecraft:glow_ink_sac",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
tag @s add mt_active
tag @s add mt_shepherd
tag @s add mt_v14
tag @s add mt_shepherd_v85
