tag @s remove mt_scholar
tag @s remove mt_craftsman
tag @s remove mt_forgemaster
tag @s remove mt_guardian
tag @s remove mt_forester
tag @s remove mt_alchemist
tag @s remove mt_curator
tag @s remove mt_traveler
tag @s remove mt_traveler_v16
tag @s remove mt_traveler_v17
tag @s remove mt_traveler_v18
tag @s remove mt_mason
tag @s remove mt_engineer
tag @s remove mt_prospector
tag @s remove mt_shepherd
tag @s remove mt_cook
tag @s remove mt_v4
tag @s remove mt_v5
tag @s remove mt_v6
tag @s remove mt_v7
tag @s remove mt_v8
tag @s remove mt_v9
tag @s remove mt_v10
tag @s remove mt_v12
tag @s remove mt_v13
tag @s remove mt_v14
data merge entity @s {VillagerData:{profession:"minecraft:butcher",level:5,type:"minecraft:jungle"},PersistenceRequired:1b,Invulnerable:0b}
data remove entity @s Offers
data modify entity @s Offers set value {Recipes:[]}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:baked_potato",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:beef",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:beetroot_soup",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:bread",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:4},sell:{id:"minecraft:cake",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:chicken",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cod",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:cooked_beef",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:cooked_chicken",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:cooked_cod",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:cooked_mutton",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:cooked_porkchop",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:cooked_rabbit",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:cooked_salmon",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cookie",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:diamond",count:32},sell:{id:"minecraft:enchanted_golden_apple",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:16},sell:{id:"minecraft:golden_apple",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:4},sell:{id:"minecraft:golden_carrot",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:mushroom_stew",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:mutton",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:porkchop",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:rabbit",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:rabbit_stew",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:salmon",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:milk_bucket",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:honey_bottle",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:pumpkin_pie",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
tag @s add mt_active
tag @s add mt_cook
tag @s add mt_v14
