# The Banker - exact-value currency exchange
# 4 gold nuggets = 1 emerald; 4 gold ingots = 9 emeralds; diamonds sell one-way only.
data merge entity @s {VillagerData:{profession:"minecraft:librarian",level:5,type:"minecraft:plains"},PersistenceRequired:1b,Xp:250}
data remove entity @s Offers
data modify entity @s Offers set value {Recipes:[]}

# Gold Nuggets <-> Emeralds (exactly even)
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:gold_nugget",count:4},sell:{id:"minecraft:emerald",count:1},uses:0,maxUses:2147483647,rewardExp:0b,xp:0,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:gold_nugget",count:4},uses:0,maxUses:2147483647,rewardExp:0b,xp:0,priceMultiplier:0.0f,demand:0,specialPrice:0}

# Gold Ingots <-> Emeralds (4 ingots = 36 nuggets = 9 emeralds)
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:gold_ingot",count:4},sell:{id:"minecraft:emerald",count:9},uses:0,maxUses:2147483647,rewardExp:0b,xp:0,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:9},sell:{id:"minecraft:gold_ingot",count:4},uses:0,maxUses:2147483647,rewardExp:0b,xp:0,priceMultiplier:0.0f,demand:0,specialPrice:0}

# Diamonds -> Emeralds ONLY. No reverse diamond purchase.
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:diamond",count:1},sell:{id:"minecraft:emerald",count:8},uses:0,maxUses:2147483647,rewardExp:0b,xp:0,priceMultiplier:0.0f,demand:0,specialPrice:0}

tag @s add mt_active
tag @s add mt_banker_v108
