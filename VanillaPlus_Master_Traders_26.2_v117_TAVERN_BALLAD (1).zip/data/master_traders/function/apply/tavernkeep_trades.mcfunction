# Tavernkeep v116 trade loader.
# Core trades load independently from special items.
function master_traders:apply/tavernkeep_core_trades
function master_traders:apply/tavernkeep_special_trades
