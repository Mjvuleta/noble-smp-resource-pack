# The Tavernkeep v115 - robust activation wrapper.
# Critical NPC setup first. If a custom trade later has a problem, the villager still activates.
data merge entity @s {Invulnerable:1b,PersistenceRequired:1b,CanPickUpLoot:0b,CustomNameVisible:0b,VillagerData:{profession:"minecraft:butcher",level:5,type:"minecraft:plains"},Xp:250}
attribute @s minecraft:movement_speed base set 0.0
tag @s add mt_active
tag @s add mt_tavernkeep_v116

# Reset trades only after the NPC has been safely activated.
data remove entity @s Offers
data modify entity @s Offers set value {Recipes:[]}

# Apply Tavernkeep trades.
function master_traders:apply/tavernkeep_trades
