# The Fisherman - v42 ocean and wildlife overhaul
data merge entity @s {VillagerData:{profession:"minecraft:fisherman",level:5,type:"minecraft:savanna"},PersistenceRequired:1b,Invulnerable:0b,Xp:250}
data remove entity @s Offers
data modify entity @s Offers set value {Recipes:[]}

# Glow ink sales - player pays gold nuggets and receives glow ink sacs
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:fishing_rod",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:32},sell:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_name":{text:"River Whisper",color:"aqua",italic:0b},"minecraft:lore":[{text:"The Fisherman’s legendary catch",color:"dark_aqua",italic:1b}],"minecraft:enchantments":{"minecraft:luck_of_the_sea":3,"minecraft:lure":3,"minecraft:unbreaking":3,"minecraft:mending":1}}},buyB:{id:"minecraft:diamond",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:5,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:string",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cod",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cooked_cod",count:6},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:cooked_salmon",count:6},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:gold_ingot",count:1},sell:{id:"minecraft:pufferfish",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:salmon",count:6},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:tropical_fish",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:10},sell:{id:"minecraft:axolotl_bucket",count:1,components:{"minecraft:custom_name":{text:"Bucket of Lucy Axolotl",color:"light_purple",italic:0b},"minecraft:bucket_entity_data":{Variant:0}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:3,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:10},sell:{id:"minecraft:axolotl_bucket",count:1,components:{"minecraft:custom_name":{text:"Bucket of Wild Axolotl",color:"gold",italic:0b},"minecraft:bucket_entity_data":{Variant:1}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:3,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:12},sell:{id:"minecraft:axolotl_bucket",count:1,components:{"minecraft:custom_name":{text:"Bucket of Gold Axolotl",color:"yellow",italic:0b},"minecraft:bucket_entity_data":{Variant:2}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:3,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:12},sell:{id:"minecraft:axolotl_bucket",count:1,components:{"minecraft:custom_name":{text:"Bucket of Cyan Axolotl",color:"aqua",italic:0b},"minecraft:bucket_entity_data":{Variant:3}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:3,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:64},sell:{id:"minecraft:axolotl_bucket",count:1,components:{"minecraft:custom_name":{text:"Bucket of Blue Axolotl",color:"blue",italic:0b},"minecraft:bucket_entity_data":{Variant:4}}},buyB:{id:"minecraft:diamond",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:5,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:4},sell:{id:"minecraft:cod_bucket",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:8},sell:{id:"minecraft:pufferfish_bucket",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:5},sell:{id:"minecraft:salmon_bucket",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:7},sell:{id:"minecraft:tropical_fish_bucket",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:4},sell:{id:"minecraft:dark_prismarine",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:dried_kelp",count:12},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:24},sell:{id:"minecraft:heart_of_the_sea",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:kelp",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:6},sell:{id:"minecraft:nautilus_shell",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:prismarine",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:prismarine_bricks",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:4},sell:{id:"minecraft:sea_lantern",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:5},sell:{id:"minecraft:sponge",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:wet_sponge",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:brain_coral_block",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:brain_coral_fan",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:bubble_coral_block",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:bubble_coral_fan",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:fire_coral_block",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:fire_coral_fan",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:gold_nugget",count:8},sell:{id:"minecraft:glow_ink_sac",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:horn_coral_block",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:horn_coral_fan",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:lead",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:sea_pickle",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:seagrass",count:8},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tube_coral_block",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:tube_coral_fan",count:4},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:8},sell:{id:"minecraft:turtle_egg",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:6},sell:{id:"minecraft:turtle_scute",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:cod",count:16},sell:{id:"minecraft:emerald",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:ink_sac",count:12},sell:{id:"minecraft:emerald",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:nautilus_shell",count:2},sell:{id:"minecraft:emerald",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:pufferfish",count:6},sell:{id:"minecraft:emerald",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:salmon",count:12},sell:{id:"minecraft:emerald",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:tropical_fish",count:8},sell:{id:"minecraft:emerald",count:1},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}


# Fishing supplies

# Fresh and cooked fish

# Fish buckets

# Axolotl buckets - each variant is explicitly stored in bucket entity data

# Ocean blocks and treasures

# Coral blocks

# Coral fans

# Fisherman buyback trades
# Glow ink specialist buyback - better than The Trader baseline

# Legendary signature rod - deliberately last

tag @s add mt_active
tag @s add mt_fisherman
tag @s add mt_fisherman_v85
