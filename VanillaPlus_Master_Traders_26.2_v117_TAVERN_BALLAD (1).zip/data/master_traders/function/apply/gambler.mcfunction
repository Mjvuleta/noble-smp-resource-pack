# The Gambler has no normal trades. Drop valuable blocks nearby to gamble.
tag @s remove mt_gambler
tag @s remove mt_gambler_v91
tag @s remove mt_gambler_v92
tag @s remove mt_gambler_v45
tag @s remove mt_gambler_v90
data merge entity @s {VillagerData:{profession:"minecraft:cartographer",level:5,type:"minecraft:jungle"},PersistenceRequired:1b,Invulnerable:0b,CanPickUpLoot:0b,Inventory:[]}
data remove entity @s Offers
data modify entity @s Offers set value {Recipes:[]}
tag @s add mt_active
tag @s add mt_gambler
tag @s add mt_gambler_v92
