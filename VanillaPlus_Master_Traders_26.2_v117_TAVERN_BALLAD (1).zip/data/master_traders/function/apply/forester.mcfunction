tag @s remove mt_scholar
tag @s remove mt_craftsman
tag @s remove mt_forgemaster
tag @s remove mt_guardian
tag @s remove mt_forester
tag @s remove mt_alchemist
tag @s remove mt_curator
tag @s remove mt_traveler
tag @s remove mt_traveler_v16
tag @s remove mt_traveler_v17
tag @s remove mt_traveler_v18
tag @s remove mt_mason
tag @s remove mt_engineer
tag @s remove mt_prospector
tag @s remove mt_shepherd
tag @s remove mt_cook
tag @s remove mt_v4
tag @s remove mt_v5
tag @s remove mt_v6
tag @s remove mt_v7
tag @s remove mt_v8
tag @s remove mt_v9
tag @s remove mt_v10
tag @s remove mt_v12
tag @s remove mt_v13
tag @s remove mt_v14
data merge entity @s {VillagerData:{profession:"minecraft:nitwit",level:5,type:"minecraft:swamp"},PersistenceRequired:1b,Invulnerable:0b}
data remove entity @s Offers
data modify entity @s Offers set value {Recipes:[]}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:oak_log",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:spruce_log",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:birch_log",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:jungle_log",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:acacia_log",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:dark_oak_log",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:mangrove_log",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:cherry_log",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:pale_oak_log",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:bamboo_block",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:crimson_stem",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:warped_stem",count:16},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:28},sell:{id:"minecraft:bow",count:1,components:{"minecraft:enchantments":{"minecraft:power":5,"minecraft:flame":1,"minecraft:punch":2,"minecraft:infinity":1,"minecraft:unbreaking":3}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:28},sell:{id:"minecraft:bow",count:1,components:{"minecraft:enchantments":{"minecraft:power":5,"minecraft:flame":1,"minecraft:punch":2,"minecraft:mending":1,"minecraft:unbreaking":3}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:30},sell:{id:"minecraft:crossbow",count:1,components:{"minecraft:enchantments":{"minecraft:quick_charge":3,"minecraft:multishot":1,"minecraft:mending":1,"minecraft:unbreaking":3}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:30},sell:{id:"minecraft:crossbow",count:1,components:{"minecraft:enchantments":{"minecraft:quick_charge":3,"minecraft:piercing":4,"minecraft:mending":1,"minecraft:unbreaking":3}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:1},sell:{id:"minecraft:arrow",count:64},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:2},sell:{id:"minecraft:spectral_arrow",count:32},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:poison"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:strong_harming"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:strong_healing"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:strong_regeneration"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:strong_strength"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:strong_swiftness"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:slowness"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:weakness"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:fire_resistance"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:night_vision"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:invisibility"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:water_breathing"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:strong_leaping"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:slow_falling"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:emerald",count:3},sell:{id:"minecraft:tipped_arrow",count:16,components:{"minecraft:potion_contents":{potion:"minecraft:turtle_master"}}},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
data modify entity @s Offers.Recipes append value {buy:{id:"minecraft:stick",count:16},sell:{id:"minecraft:gold_nugget",count:2},maxUses:2147483647,uses:0,rewardExp:1b,xp:1,priceMultiplier:0.0f,demand:0,specialPrice:0}
tag @s add mt_active
tag @s add mt_forester
tag @s add mt_v14
tag @s add mt_forester_v85
tag @s add mt_forester_v85
