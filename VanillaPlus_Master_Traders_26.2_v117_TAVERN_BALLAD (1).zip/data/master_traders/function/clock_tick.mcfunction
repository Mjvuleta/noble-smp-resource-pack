# Keep the jackpot clock synchronized to game ticks while evaluating only once per second.
scoreboard players add #gambler_day_timer mt_temp 20
execute if score #gambler_day_timer mt_temp matches 24000.. run function master_traders:gambler/daily_update
schedule function master_traders:clock_tick 20t replace
