execute as @e[type=minecraft:villager,name="The Lightbearer"] at @s run function master_traders:apply/lightbearer
execute as @e[type=minecraft:villager,name="The Light Bearer"] at @s run function master_traders:apply/lightbearer
tellraw @a [{"text":"[Master Traders v30] ","color":"gold"},{"text":"The Lightbearer was refreshed without Beacon, Conduit, or Respawn Anchor.","color":"green"}]
