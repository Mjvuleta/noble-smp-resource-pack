# Legacy entry point retained for compatibility. Workloads are scheduled from load.mcfunction.
