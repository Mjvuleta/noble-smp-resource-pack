# Handle dropped-item trades ten times per second; Trader sales process full stacks instantly.
execute as @e[type=minecraft:item] at @s if entity @e[type=minecraft:villager,name="The Mason",distance=..2.5,limit=1] run function master_traders:drop_sell/check_blocks
execute as @e[type=minecraft:item] at @s unless entity @e[type=minecraft:villager,name="The Mason",distance=..2.5,limit=1] if entity @e[type=minecraft:villager,name="The Trader",distance=..2.5,limit=1] run function master_traders:drop_sell/check
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:gold_nugget"}}] at @s if entity @e[type=minecraft:villager,name="The Traveler",distance=..2.5,limit=1] run function master_traders:drop_exchange/traveler_gold
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:emerald"}}] at @s if entity @e[type=minecraft:villager,name="The Alchemist",distance=..2.5,limit=1] run function master_traders:drop_exchange/alchemist_emerald
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:stick"}}] at @s if entity @e[type=minecraft:villager,name="The Forester",distance=..2.5,limit=1] run function master_traders:drop_exchange/forester_sticks
execute as @e[type=minecraft:item] at @s if items entity @s contents minecraft:firework_star[minecraft:custom_data~{tavern_item:"gamblers_coin"}] if entity @e[type=minecraft:villager,name="The Tavernkeep",distance=..2.5,limit=1] run function master_traders:tavern/gamblers_coin
schedule function master_traders:item_scan 2t replace
