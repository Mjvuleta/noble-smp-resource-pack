# Explicit priority support for the two system traders.
# They use the exact same custom villager-leading framework as every other named villager.
execute unless entity @s[tag=mt_lead_done] as @e[type=minecraft:villager,name="The Taskmaster",distance=..0.8,limit=1,sort=nearest] at @s run function master_traders:lead_villager/attach
execute unless entity @s[tag=mt_lead_done] as @e[type=minecraft:villager,name="The Banker",distance=..0.8,limit=1,sort=nearest] at @s run function master_traders:lead_villager/attach

# All other villagers remain lead-compatible too.
execute unless entity @s[tag=mt_lead_done] as @e[type=minecraft:villager,distance=..0.8,limit=1,sort=nearest] at @s run function master_traders:lead_villager/attach

# Continue forward up to roughly normal interaction reach if no villager was found yet.
scoreboard players add @s mt_lead_ray 1
execute unless entity @s[tag=mt_lead_done] if score @s mt_lead_ray matches ..12 positioned ^ ^ ^0.35 run function master_traders:lead_villager/raycast
