# Repeatable trigger: crouch + right-click a villager with a lead.
advancement revoke @s only master_traders:leash_villager

# Keep one temporary player context so the raycast can copy this player's UUID to the clicked villager.
tag @a remove mt_lead_user
tag @a remove mt_lead_done
tag @s add mt_lead_user
scoreboard players set @s mt_lead_ray 0

# Raycast from the player's eyes so crowded trading halls target the villager actually being looked at.
execute anchored eyes positioned ^ ^ ^0.45 run function master_traders:lead_villager/raycast

tag @s remove mt_lead_user
tag @s remove mt_lead_done
