THE STABLEMASTER
Rename any villager exactly: The Stablemaster
Appearance: Taiga Fletcher

Mount deeds are goat horns. Right-click a deed to consume it and summon a randomized, named, tamed, saddled mount.
The Stablemaster's Bell calls your nearest purchased horse, donkey, or mule within 64 blocks.

After installing, run:
/reload
/function master_traders:refresh_all
